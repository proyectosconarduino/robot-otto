README
======
Modified OTTO Head and Body STL files, these are slightly larger than the originals to allow fitting of MAX7219 LED MATRIX
Print at 20% infill
0.15mm resolution or better



